---
title: "Yash Off Campus Drive For Freshers"
company: "Yash Technologies"
location: "India"
date: 2025-06-01
link: "https://apply.example.com"
layout: "job.njk"
---

Yash is hiring freshers for a Software Engineer role. Apply before June 10th.