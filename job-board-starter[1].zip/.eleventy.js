module.exports = function(eleventyConfig) {
  eleventyConfig.addPassthroughCopy("css");
  eleventyConfig.addCollection("jobs", function(collectionApi) {
    return collectionApi.getFilteredByGlob("./jobs/*.md");
  });
  return {
    dir: {
      input: ".",
      includes: "layouts",
      data: "_data",
      output: "_site"
    }
  };
};